from webbrowser import get
from flask import render_template,request, redirect,session,flash,jsonify
from flask_app import app
from flask_app.models.user import User
from flask_app.controllers import users

import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
from flask_app import Bcrypt
bcrypt = Bcrypt(app)



@app.route('/')
def sample():
    return render_template('index.html')

    

@app.route('/create',methods=['POST'])
def create_user():
    if not User.validator(request.form):
        return redirect('/')

    pw_hash=bcrypt.generate_password_hash(request.form['pw'])
    data = {
        **request.form,
        "pw" : pw_hash
    }
    id=User.save(data)
    if not id:
        flash("Email already taken.")
        return redirect('/')
    session['uuid'] =id
    return redirect('/user/dashboard/')

@app.route('/login', methods=['POST'])
def login():
    data={
        "email":request.form['email']
    }
    real_user=User.get_one_by_email(data)

    if not real_user:
        flash('Invalid Email/Password!','err_user_email_log')
        return redirect('/')
    if not bcrypt.check_password_hash(real_user.pw,request.form['pw']):
        flash('Invalid Email/Password!','err_user_pw_login')
        return redirect('/')
    session['uuid']=real_user.id
    return redirect('/user/dashboard/')


@app.route('/logout')
def logout():
    del session['uuid']
    return redirect('/')


@app.route('/user/dashboard/')
def results():
    if 'uuid' in session:
        user=User.get_one({'id':session['uuid']})
    if not 'uuid' in session:
        return render_template('dashboard.html')
    return render_template('dashboard.html',user=user)