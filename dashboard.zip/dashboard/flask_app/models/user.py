from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

DATABASE='dashboard'

class User:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.location = data['location']
        self.email = data['email']
        self.pw = data['pw']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
    @property
    def fullname(self):
        return f"{self.first_name.capitalize()} {self.last_name.capitalize()}"

    @classmethod
    def save(cls,data):
        query = "INSERT INTO user (first_name,last_name,location,email,pw,created_at,updated_at) VALUES(%(first_name)s,%(last_name)s,%(location)s,%(email)s,%(pw)s,NOW(),NOW())"
        return connectToMySQL(DATABASE).query_db(query,data)


    @classmethod
    def get_all(cls):
        query = "SELECT * FROM user;"
        results = connectToMySQL(DATABASE).query_db(query)
        user = []
        for friend in results:
            user.append( cls(friend) )
        return user

    @classmethod
    def get_one(cls,data:dict):
        query = "SELECT * FROM user WHERE id=%(id)s;"
        results = connectToMySQL(DATABASE).query_db(query,data)
        return cls(results[0])

    @classmethod
    def get_city(cls,data:dict):
        query ='SELECT * FROM user WHERE location=%(location)s;'
        results = connectToMySQL(DATABASE).query_db(query,data)
        if results:
            return User(results[0])

        

    @classmethod
    def get_one_by_email(cls,data:dict):
        query = "SELECT * FROM user WHERE email=%(email)s;"
        results = connectToMySQL(DATABASE).query_db(query,data)
        if results:
            return User(results[0])

    
    @classmethod
    def delete(cls,data):
        query="DELETE FROM user WHERE id=%(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)

    @classmethod
    def update(cls,data):
        query="UPDATE user SET(location,updated_at) VALUES (%(location)s,NOW() ) WHERE id= %(id)s;"
        return connectToMySQL(DATABASE).query_db(query,data)

    @staticmethod
    def validator(form_data:dict):
        is_valid = True
        query = "SELECT * FROM user WHERE email=%(email)s;"
        results = connectToMySQL(DATABASE).query_db(query,form_data)

        if len(results) >=1:
            flash('Email already taken!','err_user_email')
            is_valid=False

        if len(form_data['first_name']) <= 0:
            is_valid = False
            flash('First Name is required! ','err_user_first')

        if len(form_data['last_name']) < 1:
            is_valid = False
            flash('Last Name required!', 'err_user_last')

        if len(form_data['location']) <= 0:
            is_valid = False
            flash('Location required! ','err_user_location')

        if len(form_data['email']) < 1:
            is_valid = False
            flash('Emailis required!','err_user_email')
        

        if len(form_data['pw']) <= 0:
            is_valid = False
            flash("pw is required,at least 8 characters long!.",'err_user_pw')
        pw1=form_data['pw']
        pw2=form_data['confirm']
        if pw1 != pw2 :
            is_valid = False
            flash("password needs to match!",'err_user_confirm')
        return is_valid
