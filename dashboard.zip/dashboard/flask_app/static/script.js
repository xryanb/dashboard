
//timeapi
async function onCall(){
    var response = await fetch("https://www.timeapi.io/api/Time/current/ip?ipAddress=1.1.1.1");
    var coderData = await response.json();
    let currTime=coderData;
    console.log(currTime);
    let time=coderData.time;
    console.log(time);
    let theDay=coderData.dayOfWeek;
    let date=coderData.date;
    console.log(date);
    let ryanDiv=document.querySelector('#local-time')
    ryanDiv.innerHTML = `
    <pre>
    <h2 class='day'>${theDay}</h2>
    <br>
    <h2 class='date'>${date}</h2>
    <br>
    <h3 class='time'>${time}</h3>
    </pre>`
}

setInterval(onCall,1000);

// onCall();


//weather-api

async function localWeather(){
    let name=document.querySelector('#area').value;
    console.log(name);
    var response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${name}&units=imperial&appid=371730e0b420030ea0c6ffe850034ee4`);
    var data = await response.json();
    console.log(data);
    let city_name=data['name'];
    let weather=data.weather[0].description;
    let wTemp=data.main.temp_max;
    let imgW=data.weather[0].icon;
    let weatherDiv=document.querySelector('#weather');
    weatherDiv.innerHTML = `
    <div class='info'>
    <img src="http://openweathermap.org/img/wn/${imgW}.png" alt="">
    <p>${weather}</p>
    <p>${wTemp} &#8457</p>
    <p> ${city_name}</p>
    </div>
    `
}

// localWeather();

setInterval(localWeather,1000);
