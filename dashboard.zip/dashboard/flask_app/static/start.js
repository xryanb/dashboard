



function passvalues() {

    var location=document.getElementById("#location").value;
    localStorage.setItem('textvalue',location);
    return false;
}